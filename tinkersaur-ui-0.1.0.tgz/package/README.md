# @tinkersaur/ui

A modern React component library built with TailwindCSS v4, designed for desktop-focused enterprise applications.

## Features

- 34 production-ready components
- Built for React 19
- TailwindCSS v4 with CSS variables for theming
- Light/Dark theme support out of the box
- Full TypeScript support with exported types
- ESM and CommonJS builds

## Installation

```bash
npm install @tinkersaur/ui
```

### Peer Dependencies

This library requires the following peer dependencies:

```bash
npm install react react-dom tailwind-merge @floating-ui/react
```

#### Optional Peer Dependencies

Install based on which components you use:

| Component | Peer Dependency |
|-----------|-----------------|
| `Table` | `@tanstack/react-table@^8.0.0` |
| `Form` | `react-hook-form@^7.0.0` |
| `DatePicker` | `date-fns@^3.0.0 \|\| ^4.0.0` |
| `MarkdownContent` | `react-markdown@^10.0.0`, `remark-gfm@^4.0.0` |

## Quick Start

### 1. Import Styles

Import the component styles in your app's entry point:

```tsx
import '@tinkersaur/ui/styles';
```

Or import directly in CSS:

```css
@import '@tinkersaur/ui/dist/ui.css';
```

### 2. Set Up Theme Provider

Wrap your application with the `ThemeProvider`:

```tsx
import { ThemeProvider } from '@tinkersaur/ui';

function App() {
  return (
    <ThemeProvider>
      <YourApp />
    </ThemeProvider>
  );
}
```

### 3. Use Components

```tsx
import { Button, Card, Input } from '@tinkersaur/ui';

function MyComponent() {
  return (
    <Card>
      <Input placeholder="Enter your name" />
      <Button variant="primary">Submit</Button>
    </Card>
  );
}
```

## Components

### Foundation
- `Spinner` - Loading indicator
- `Avatar` - User avatar display
- `Tag` - Colored tag/badge
- `Empty` - Empty state placeholder
- `Card` - Container card

### Form Primitives
- `Button` - Action button with variants (primary, default, text, link, danger)
- `Input` - Text input field
- `PasswordInput` - Password input with visibility toggle
- `InputNumber` - Numeric input with step controls
- `Checkbox` - Checkbox input
- `SearchInput` - Search input with icon

### Layout
- `Stack`, `HStack`, `VStack` - Flex layout utilities
- `Layout` - Page layout with Header, Sider, Content sub-components

### Overlays
- `Tooltip` - Hover tooltip (powered by Floating UI)
- `Dropdown` - Dropdown menu
- `Modal` - Modal dialog with portal rendering
- `Drawer` - Slide-out panel

### Selection
- `Select` - Single select dropdown with optional search
- `MultiSelect` - Multi-select with tags
- `DatePicker` - Date/datetime picker with calendar
- `Menu` - Hierarchical navigation menu

### Data Display
- `Tabs` - Tab navigation
- `Tree` - Tree view with drag-and-drop support
- `Table` - Data table with sorting, pagination (powered by TanStack Table)

### Form System
- `Form` - Form wrapper with validation (powered by React Hook Form)
- `Form.Item` - Form field with label and error display
- `useForm` - Form state hook
- `useFormContext` - Access form context

### Content & Feedback
- `MarkdownContent` - Render GitHub-flavored markdown
- `InlineError` - Inline error message display
- `ErrorBoundary` - Error boundary wrapper

### Composite
- `PageHeader` - Page header with title and actions
- `PageContent` - Page content wrapper
- `CardStack` - Stacked cards layout
- `EditableSection`, `EditableField` - In-place editing UI
- `ListControlPanel` - List filters, search, and action controls
- `EntityList` - Complete list page with selection, filters, pagination

## Theming

The library uses CSS custom properties for theming. Theme is controlled via the `data-theme` attribute on the document root.

### Using the Theme Hook

```tsx
import { useTheme } from '@tinkersaur/ui';

function ThemeToggle() {
  const { theme, toggleTheme, setTheme } = useTheme();

  return (
    <button onClick={toggleTheme}>
      Current: {theme}
    </button>
  );
}
```

### Available Theme Variables

```css
/* Backgrounds */
--bg-dark, --bg, --bg-light, --bg-form

/* Text */
--text, --text-muted, --text-disabled, --text-contrast

/* Colors */
--primary, --secondary, --danger, --warning, --success, --info

/* Borders */
--border, --border-muted

/* Effects */
--shadow, --shadow-hover, --highlight

/* Tags */
--tag-blue, --tag-green, --tag-orange, --tag-red, --tag-purple, --tag-cyan
```

### Custom Theme Colors

Override theme colors in your CSS:

```css
:root {
  --primary: oklch(0.5 0.15 250);
  --secondary: oklch(0.7 0.1 33);
}

[data-theme="dark"] {
  --primary: oklch(0.7 0.15 250);
  --secondary: oklch(0.8 0.1 33);
}
```

## Utilities

### cn() - Class Name Utility

Merge Tailwind classes intelligently using `tailwind-merge`:

```tsx
import { cn } from '@tinkersaur/ui';

<div className={cn('p-4', isActive && 'bg-primary', className)} />
```

### useListSelection Hook

Manage list selection state:

```tsx
import { useListSelection } from '@tinkersaur/ui';

const {
  selectedIds,
  toggleSelection,
  selectAll,
  clearSelection,
  isSelected
} = useListSelection({
  items,
  getItemId: (item) => item.id,
});
```

## TypeScript

All components export their prop types:

```tsx
import type {
  ButtonProps,
  CardProps,
  TableColumn,
  SelectOption,
  FormProps
} from '@tinkersaur/ui';
```

## Browser Support

- Chrome 90+
- Firefox 90+
- Safari 15+
- Edge 90+

## License

MIT
